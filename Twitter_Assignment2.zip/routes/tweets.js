var express = require('express');
var router = express.Router();
var MongoClient = require('mongodb').MongoClient;

var dburl = 'mongodb://52.23.184.73:27017/twitt-trend';

/* GET data in the DB initially. */
router.get('/', function(req, res, next) {
	MongoClient.connect(dburl, function(err, db) {
		if(err) {
			console.log('Connecting to Mongo failed');
			res.send([]);
		} else {
			var col = db.collection('tweets');
			if(col) {
				// only fetch the most recent 24 hrs
				col.find({
					created_at: {$gt: new Date(Date.now() - 4*60*60*1000)}
				}).toArray(function(err, docs) {
					if(err) {
						console.log('Fetching tweets from Mongo failed');
						res.send([]);
					} else {
						console.log('Successfully fetched tweets from Mongo');
						res.send(docs);
					}
				});
			} else {
				res.send([]);
			}
		}
	});
});

module.exports = router;
